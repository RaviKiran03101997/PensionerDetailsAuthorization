package com.pension;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessPensionApplicationTests {

}
