package employee.service;

import employee1.bean.employeeDetails;

public interface EmployeeService {

	employeeDetails addemployee(employeeDetails employee);
}
