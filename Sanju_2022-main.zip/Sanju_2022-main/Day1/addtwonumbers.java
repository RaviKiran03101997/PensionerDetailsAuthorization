package com.java.add;

public class addtwonumbers {
public static void main (String args[])
{
int number1=10;
int number2=15;
int result= number1+number2;
System.out.println("sum of two number:"+result);

}

}
