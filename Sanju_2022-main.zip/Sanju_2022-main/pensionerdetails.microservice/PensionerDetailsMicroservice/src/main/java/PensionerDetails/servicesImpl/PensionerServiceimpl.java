package PensionerDetails.servicesImpl;

import PensionerDetails.bean.PensionerDetails;
import PensionerDetails.services.PensionerService;

public class PensionerServiceimpl implements PensionerService {

	@Override
	public PensionerDetails getPensionerDetailsByAaddhar(long aadharcardid) {
	
		return null;
	}

	@Override
	public Integer pensionCalculator(double basicsalary, double dearnessallowance, int workedageinorganization) {
		
		return null;
	}

}
