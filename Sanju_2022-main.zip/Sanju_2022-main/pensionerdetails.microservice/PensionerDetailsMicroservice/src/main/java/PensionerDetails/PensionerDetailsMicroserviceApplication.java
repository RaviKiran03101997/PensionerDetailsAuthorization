package PensionerDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PensionerDetailsMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PensionerDetailsMicroserviceApplication.class, args);
	}

}
